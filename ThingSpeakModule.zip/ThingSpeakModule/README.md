# MQTT Secure via HTTPS Websocket Example

Uses an mbedTLS socket to make a very simple HTTPS request over a secure connection, including verifying the server TLS certificate.

See the README.md file in the upper level 'examples' directory for more information about examples.
